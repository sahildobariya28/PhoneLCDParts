//
//  SwiftToKotlin.swift
//  iosApp
//
//  Created by mac on 27/07/23.
//  Copyright © 2023 orgName. All rights reserved.
//

import Foundation
import shared

public func onBackGesture() {
    ApplicationKt.onBackGesture()
}
